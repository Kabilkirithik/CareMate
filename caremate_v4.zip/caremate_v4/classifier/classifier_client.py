"""
caremate_v4/classifier/classifier_client.py
============================================
In-process ML classifier that loads the trained scikit-learn models
(intent_model.joblib + vectorizer.joblib) directly — no HTTP service needed.

Falls back to a lightweight rule-based classifier if the model files
are missing or fail to load.

Label mapping (ML model → single_crew category)
------------------------------------------------
doctor_query        → DOCTOR_QUERY
document_submission → OCR_UPLOAD
emergency           → EMERGENCY          ← handled by emergency_precheck first;
                                            if it reaches here, treat as NURSE_REQUEST
general_conversation→ NURSE_REQUEST      ← soft fallback; nurse is safest default
nurse_request       → NURSE_REQUEST
nutrition_request   → NUTRITION_REQUEST
status_query        → STATUS_QUERY
utility_request     → UTILITY_REQUEST

Usage
-----
    from caremate_v4.classifier.classifier_client import classify_message, is_classifier_available

    result = classify_message("I need a blanket", patient_id="P-001")
    # → {"category": "UTILITY_REQUEST", "confidence": 0.77, "source": "ml_model"}
"""

import logging
import os
import re
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# =============================================================
# PATHS
# =============================================================

_HERE        = Path(__file__).parent                   # caremate_v4/classifier/
_ML_MODEL    = _HERE.parent / "ml_model" / "intent_model.joblib"
_VECTORIZER  = _HERE.parent / "ml_model" / "vectorizer.joblib"

# =============================================================
# LABEL → CATEGORY MAP
# =============================================================

_LABEL_TO_CATEGORY: dict[str, str] = {
    "doctor_query":         "DOCTOR_QUERY",
    "document_submission":  "OCR_UPLOAD",
    "emergency":            "NURSE_REQUEST",   # precheck fires first; this is a safe fallback
    "general_conversation": "NURSE_REQUEST",   # nurse is the safest general fallback
    "nurse_request":        "NURSE_REQUEST",
    "nutrition_request":    "NUTRITION_REQUEST",
    "status_query":         "STATUS_QUERY",
    "utility_request":      "UTILITY_REQUEST",
}

# =============================================================
# MODEL LOADING (once, at import time)
# =============================================================

_model      = None
_vectorizer = None
_ml_ready   = False

def _load_models() -> bool:
    """Load joblib models. Returns True on success, False on any failure."""
    global _model, _vectorizer, _ml_ready

    try:
        import joblib  # type: ignore

        if not _ML_MODEL.exists():
            logger.warning("intent_model.joblib not found at %s", _ML_MODEL)
            return False
        if not _VECTORIZER.exists():
            logger.warning("vectorizer.joblib not found at %s", _VECTORIZER)
            return False

        _vectorizer = joblib.load(str(_VECTORIZER))
        _model      = joblib.load(str(_ML_MODEL))
        _ml_ready   = True
        logger.info("✅ ML classifier loaded (vocab=%d, classes=%s)",
                    len(_vectorizer.vocabulary_), list(_model.classes_))
        return True

    except Exception as exc:
        logger.warning("ML model load failed (%s) — falling back to rule-based classifier", exc)
        return False


_load_models()

# =============================================================
# PUBLIC API
# =============================================================

def is_classifier_available() -> bool:
    """Return True if the ML models loaded successfully."""
    return _ml_ready


def classify_message(
    message: str,
    patient_id: Optional[str] = None,  # kept for logging / future use
) -> dict:
    """
    Classify a patient message into a CareMate workflow category.

    Returns
    -------
    dict with keys:
        category   (str)   — one of the TOOL_INSTRUCTIONS keys in single_crew.py
        confidence (float) — 0.0 – 1.0
        source     (str)   — "ml_model" | "rule_based"
    """
    if not message or not message.strip():
        return {"category": "NURSE_REQUEST", "confidence": 0.5, "source": "rule_based"}

    if _ml_ready:
        return _classify_ml(message)
    else:
        return _classify_rules(message)


# =============================================================
# ML PATH
# =============================================================

def _classify_ml(message: str) -> dict:
    """Use the loaded TF-IDF + LogisticRegression pipeline."""
    try:
        X       = _vectorizer.transform([message])
        label   = _model.predict(X)[0]
        proba   = _model.predict_proba(X)[0]
        confidence = float(max(proba))
        category   = _LABEL_TO_CATEGORY.get(label, "NURSE_REQUEST")

        return {
            "category":   category,
            "confidence": round(confidence, 4),
            "source":     "ml_model",
        }

    except Exception as exc:
        logger.warning("ML inference failed (%s) — falling back to rules", exc)
        return _classify_rules(message)


# =============================================================
# RULE-BASED FALLBACK
# =============================================================

# Each entry: (category, keywords_list, weight)
# Weight allows multi-word phrases to score higher than single tokens.
_RULES: list[tuple[str, list[str], int]] = [
    ("UTILITY_REQUEST",   ["blanket", "wheelchair", "charger", "housekeeping",
                           "clean", "fan", "light", "bedsheet", "bed sheet",
                           "pillow", "remote", "tv"], 1),
    ("NURSE_REQUEST",     ["nurse", "assist", "assistance", "come here",
                           "need help", "water", "pain", "uncomfortable",
                           "call someone"], 1),
    ("NUTRITION_REQUEST", ["food", "meal", "eat", "hungry", "diet",
                           "breakfast", "lunch", "dinner", "snack", "drink"], 1),
    ("STATUS_QUERY",      ["status", "update", "waiting", "where is",
                           "any news", "yet", "still", "progress", "done yet"], 1),
    ("DOCTOR_QUERY",      ["doctor", "medicine", "medication", "diagnosis",
                           "treatment", "disease", "why do i", "health question",
                           "medical", "prescription"], 1),
    ("OCR_UPLOAD",        ["upload", "report", "document", "scan",
                           "prescription", "record", "file", "submit"], 1),
]

def _classify_rules(message: str) -> dict:
    """Lightweight keyword-scoring fallback classifier."""
    text   = message.lower()
    tokens = set(re.findall(r"\b\w+\b", text))
    scores: dict[str, int] = {}

    for category, keywords, weight in _RULES:
        score = 0
        for kw in keywords:
            if " " in kw:                  # multi-word phrase
                if kw in text:
                    score += weight * 2
            elif kw in tokens:
                score += weight
        if score:
            scores[category] = score

    if not scores:
        return {"category": "NURSE_REQUEST", "confidence": 0.4, "source": "rule_based"}

    best       = max(scores, key=scores.get)
    total      = sum(scores.values())
    confidence = round(scores[best] / total, 4) if total else 0.5

    return {
        "category":   best,
        "confidence": confidence,
        "source":     "rule_based",
    }