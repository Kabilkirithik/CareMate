from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Type, Optional
import requests
import base64
import os


# -----------------------------
# Input Schema
# -----------------------------
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Type, Optional, ClassVar
import requests
import base64
import os


class OCRSubmissionInput(BaseModel):
    patient_id: str = Field(..., description="Patient ID")
    file_path: str = Field(..., description="Path to image or PDF")
    document_type: Optional[str] = Field(None, description="Optional document type hint")


class OCRSubmissionTool(BaseTool):

    name: str = "OCR Submission Tool"
    description: str = "Submit hospital documents to OCR microservice."

    args_schema: Type[OCRSubmissionInput] = OCRSubmissionInput

    OCR_SERVICE_URL: ClassVar[str] = "http://localhost:8001/ocr/submit"

    args_schema: Type[OCRSubmissionInput] = OCRSubmissionInput

    OCR_SERVICE_URL = "http://localhost:8001/ocr/submit"

    def _run(self, patient_id: str, file_path: str, document_type: Optional[str] = None):

        try:
            # detect file type
            file_extension = os.path.splitext(file_path)[1].lower()

            if file_extension not in [".jpg", ".jpeg", ".png", ".pdf"]:
                return {
                    "status": "error",
                    "message": "Unsupported file type. Only images and PDFs allowed."
                }

            # read file
            with open(file_path, "rb") as f:
                encoded_document = base64.b64encode(f.read()).decode("utf-8")

            payload = {
                "patient_id": patient_id,
                "file_type": file_extension.replace(".", ""),
                "document_base64": encoded_document,
                "document_type": document_type
            }

            response = requests.post(self.OCR_SERVICE_URL, json=payload)

            if response.status_code == 200:
                return response.json()

            return {
                "status": "error",
                "message": "OCR submission failed",
                "details": response.text
            }

        except Exception as e:
            return {
                "status": "error",
                "message": str(e)
            }